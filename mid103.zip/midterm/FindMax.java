import java.util.Random;
import java.util.Scanner;

public class FindMax {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Random random = new Random();

        // รับค่า n จากผู้ใช้
        System.out.print("Enter n: ");
        int n = scanner.nextInt();

        // สร้างอาร์เรย์เก็บตัวเลขแบบสุ่ม
        int[] numbers = new int[n];
        for (int i = 0; i < n; i++) {
            numbers[i] = random.nextInt(201) - 100; // สุ่มค่าในช่วง [-100, 100]
        }

        // แสดงตัวเลขทั้งหมดที่สร้างขึ้น
        System.out.print("Numbers:");
        for (int num : numbers) {
            System.out.print(" " + num);
        }
        System.out.println();

        // คำนวณค่าต่างที่มากที่สุด
        int maxDiff = 0;
        int num1 = 0, num2 = 0;

        for (int i = 0; i < n; i++) {
            for (int j = i + 1; j < n; j++) {
                int diff = Math.abs(numbers[i] - numbers[j]);
                if (diff > maxDiff) {
                    maxDiff = diff;
                    num1 = numbers[i];
                    num2 = numbers[j];
                }
            }
        }

        // แสดงผลลัพธ์
        System.out.println("Maximum absolute difference: " + maxDiff);
        System.out.println("Numbers that gives maximum absolute difference: " + num1 + " " + num2);

        scanner.close();
    }
}
