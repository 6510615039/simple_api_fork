import java.util.Scanner;

public class TestPoint {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter x y: ");
        double x = sc.nextDouble();
        double y = sc.nextDouble();

        Point p1 = new Point();
        Point p2 = new Point(x, y);
        Point p3 = new Point(p2);

        System.out.println("p1: " + p1);
        System.out.println("p2: " + p2);
        System.out.println("p3: " + p3);

        System.out.printf("p1 %s: distance from origin = %.2f\n", p1, p1.distance());
        System.out.printf("p2 %s: distance from origin = %.2f\n", p2, p2.distance());
        System.out.printf("p3 %s: distance from origin = %.2f\n", p3, p3.distance());

        System.out.printf("p2 %s: distance from (0, 0) = %.2f\n", p2, p2.distance(0, 0));
        System.out.printf("p3 %s: distance from (0, 0) = %.2f\n", p3, p3.distance(0, 0));

        System.out.printf("p2 %s: distance from (%.1f, %.1f) = %.2f\n", p2, p1.getX(), p1.getY(), p2.distance(p1));
        System.out.printf("p3 %s: distance from (%.1f, %.1f) = %.2f\n", p3, p1.getX(), p1.getY(), p3.distance(p1));

        sc.close();
    }
}
