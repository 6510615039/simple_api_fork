import java.util.Scanner;

public class Words {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // รับข้อความจากผู้ใช้
        System.out.print("Enter a line of text: ");
        String input = scanner.nextLine();

        // ประมวลผลข้อความแทนที่พยัญชนะด้วย '*'
        String processedText = processText(input);

        // แสดงผลลัพธ์
        System.out.println("Processed words: " + processedText);

        scanner.close();
    }

    public static String processText(String text) {
        StringBuilder result = new StringBuilder();
        String vowels = "AEIOUaeiou";

        for (char c : text.toCharArray()) {
            if (Character.isLetter(c) && !vowels.contains(String.valueOf(c))) {
                result.append('*'); // แทนที่พยัญชนะด้วย '*'
            } else {
                result.append(c); // เก็บตัวอักษรเดิม (สระ, ตัวเลข, และช่องว่าง)
            }
        }

        return result.toString();
    }
}
