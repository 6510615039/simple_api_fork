import java.util.Scanner;

public class Vowel {

    // ฟังก์ชันหาว่าสัญลักษณ์เป็นสระหรือไม่
    public static boolean findVowel(char c) {
        return "aeiouAEIOU".indexOf(c) != -1;
    }

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        System.out.print("Enter a line of text: ");
        String text = sc.nextLine();

        // สร้าง StringBuilder สำหรับเก็บผลลัพธ์
        StringBuilder result = new StringBuilder();

        // เปลี่ยนแต่ละตัวอักษรในข้อความ
        for (char i : text.toCharArray()) {
            if (findVowel(i)) {
                result.append("*");  // ถ้าเป็นสระ ให้แสดงเป็น "*"
            } else {
                result.append(i);  // ถ้าไม่ใช่สระ ให้แสดงตัวอักษรเดิม
            }
        }

        // แสดงผลลัพธ์ที่ได้
        System.out.println("Processed words: " + result.toString());
    }
}
