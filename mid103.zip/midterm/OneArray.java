import java.util.Scanner;

public class OneArray {

    // Method to process the input array
    public static int[] process(int[] a) {
        int n = a.length;
        int[] result = new int[2 * n - 1]; // Initialize new array of size 2n - 1
        
        result[0] = a[0]; // First element remains the same
        
        for (int i = 1; i < n; i++) {
            result[2 * i - 1] = Math.abs(a[i] - a[i - 1]); // Absolute difference between adjacent elements
            result[2 * i] = a[i]; // Copy the element itself
        }

        return result; // Return the new array
    }

    // Main method to interact with the user
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.print("Enter number of integers: ");
        int n = scanner.nextInt(); // Read number of integers
        int[] a = new int[n];
        
        System.out.print("Enter a list of integers: ");
        for (int i = 0; i < n; i++) {
            a[i] = scanner.nextInt(); // Read each integer into the array
        }
        
        int[] result = process(a); // Process the array to get the new one
        
        System.out.print("New list of integers: ");
        for (int num : result) {
            System.out.print(num + " "); // Print the new list
        }
    }
}
