package student;

public class Student {
    private String id;
    private String firstname;
    private String surname;
    private byte status;

    // Constructor
    public Student(String id, String firstname, String surname, byte status) {
        this.id = id;
        this.firstname = firstname;
        this.surname = surname;
        this.status = status;
    }

    // Getter methods
    public String getId() {
        return id;
    }

    public String getFirstname() {
        return firstname;
    }

    public String getSurname() {
        return surname;
    }

    public byte getStatus() {
        return status;
    }

    // Method to convert status to string
    public String getStatusString() {
        switch (status) {
            case 1: return "Normal";
            case 2: return "Warning 1";
            case 3: return "Warning 2";
            case 4: return "Probation";
            case 5: return "Graduated";
            case 6: return "On Leave";
            case 7: return "Retired";
            default: return "Unknown";
        }
    }

    @Override
    public String toString() {
        return "ID: " + id + ", Name: " + firstname + " " + surname + ", Status: " + getStatusString();
    }
}
