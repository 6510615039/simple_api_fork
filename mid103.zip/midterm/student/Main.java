package student;

import java.util.Scanner;


public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // รับข้อมูลนักเรียน
        System.out.print("Enter student ID: ");
        String id = scanner.nextLine();

        System.out.print("Enter firstname: ");
        String firstname = scanner.nextLine();

        System.out.print("Enter surname: ");
        String surname = scanner.nextLine();

        System.out.print("Enter status (1-7): ");
        byte status = scanner.nextByte();

        // สร้าง Object Student
        Student student = new Student(id, firstname, surname, status);

        // แสดงผลข้อมูลนักเรียน
        System.out.println("\nStudent Info:");
        System.out.println(student);

        scanner.close();
    }
}
