import java.util.Scanner;

public class MarkDigit {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // รับข้อมูลจากผู้ใช้
        System.out.print("Enter a line of text: ");
        String input = scanner.nextLine();

        System.out.print("Enter character to be marked: ");
        char toBeMarked = scanner.next().charAt(0);

        System.out.print("Enter character for marking: ");
        char markingChar = scanner.next().charAt(0);

        // ลบตัวอักษรที่ไม่ใช่ตัวเลข
        String removed = removeNonDigit(input);
        System.out.println("After removed: " + removed);

        // แทนที่ตัวเลขที่กำหนดด้วยเครื่องหมายที่ระบุ
        String marked = markDigit(removed, toBeMarked, markingChar);
        System.out.println("After marked: " + marked);

        scanner.close();
    }

    // เมธอดลบตัวอักษรที่ไม่ใช่ตัวเลข
    public static String removeNonDigit(String s) {
        return s.replaceAll("[^0-9]", ""); // ใช้ regex แทนที่ทุกตัวอักษรที่ไม่ใช่ตัวเลขด้วย ""
    }

    // เมธอดแทนที่ตัวเลขที่กำหนดด้วยเครื่องหมายที่ระบุ
    public static String markDigit(String s, char ch, char mark) {
        return s.replace(ch, mark); // ใช้ replace() แทนที่อักขระเป้าหมายด้วยอักขระแทนที่
    }
}
