
/**
 *
 * @author xxxxxxxxxx@cn103
 * 
 */

import java.util.Scanner;

public class TestIpAddress {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter an IPv4 address: ");
        String line = sc.nextLine().trim();
        sc.close();

        MyIpAddress ip = new MyIpAddress(line);

        boolean res = ip.isValid();
        ip.printWhyIsNotGood();

        System.out.print("\n" + line);
        if (res) {
            System.out.println(" is a valid IP address");
        } else {
            System.out.println(" is NOT a valid IP adderss");
        }
    }

}
