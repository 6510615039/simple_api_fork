
/**
 *
 * @author @cn103
 * 
 */

import java.util.Scanner;

public class MixedHex {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter string of hex digits (in pairs): ");
        String hex1 = sc.nextLine();
        System.out.print("Enter string of hex digits (in pairs): ");
        String hex2 = sc.nextLine();
        System.out.print("Enter a delimiter: ");
        String delimeter = sc.nextLine();
        int pairs = Math.min(hex1.length(), hex2.length());
        int leftPairs = Math.abs(hex1.length() - hex2.length());
        String mix = "";
        int count = 0;
        String moreNum;

        if (hex1.length() >= hex2.length()) {
            moreNum = hex1;
        } else {
            moreNum = hex2;
        }
        for (int i = 0; i < pairs + leftPairs; i += 2) {
            if (count < pairs / 2) {
                mix += hex1.charAt(i);
                mix += hex1.charAt(i + 1);
                mix += delimeter;
                mix += hex2.charAt(i);
                mix += hex2.charAt(i + 1);
                mix += delimeter;
                count += 1;
            } else {
                mix += moreNum.charAt(i);
                mix += moreNum.charAt(i + 1);
                mix += delimeter;
                count += 1;
            }
        }
        System.out.println("Mixed hex: " + mix.substring(0, mix.length() - delimeter.length()));
    }
}
