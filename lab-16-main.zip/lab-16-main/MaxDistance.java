
/**
 *
 * @author @cn103
 * 
 */

import java.util.Scanner;

public class MaxDistance {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        System.out.print("Enter centre: ");
        String s1 = sc.nextLine();
        int x = Integer.parseInt("" + s1.charAt(0));
        int y = Integer.parseInt("" + s1.charAt(2));
        System.out.print("Enter other points: ");
        String s2 = sc.nextLine();
        String[] arr = s2.split(" ");
        int[] numArr = new int[arr.length];
        for (int k = 0; k < numArr.length; k++) {
            numArr[k] = Integer.parseInt(arr[k]);
        }
        double maxDistance = Math.sqrt(Math.pow(x - numArr[0], 2) + Math.pow(y - numArr[1], 2));
        int xMax = numArr[0];
        int yMax = numArr[1];
        for (int i = 2; i < numArr.length; i += 2) {
            double distance = Math.sqrt(Math.pow(x - numArr[i], 2) + Math.pow(y - numArr[i + 1], 2));
            if (distance >= maxDistance) {
                maxDistance = distance;
                xMax = numArr[i];
                yMax = numArr[i + 1];
            }
        }
        System.out.println("Point for max distance: " + xMax + " " + yMax);
        System.out.println("Max distance: " + String.format("%.1f", maxDistance));

    }

}
