
/**
 *
 * @author xxxxxxxxxx@cn103
 * 
 */

import java.util.Scanner;

public class TestAnimal {

    public static void print(Animal an) {
        String s = "  eat: " + an.eat() + "\n";
        s += "  sound: " + an.sound() + "\n";
        System.out.print(s);
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int age;
        String color;
        System.out.print("Enter dog info (age color): ");
        age = sc.nextInt();
        color = sc.next().trim();
        Dog dog = new Dog(age, color);

        System.out.print("Enter bird info (age color): ");
        age = sc.nextInt();
        color = sc.next().trim();
        Bird bird = new Bird(age, color);
        System.out.println();

        System.out.println("Dog: " + dog);
        print(dog);
        System.out.println("  move: " + dog.howToMove());
        System.out.println();

        System.out.println("Bird: " + bird);
        print(bird);
        System.out.println("  move: " + bird.howToMove());
        System.out.println();

        System.out.print("Change dog (age color): ");
        age = sc.nextInt();
        color = sc.next().trim();
        dog.setAge(age);
        dog.setColor(color);

        System.out.print("Change bird (age color): ");
        age = sc.nextInt();
        color = sc.next().trim();
        bird.setAge(age);
        bird.setColor(color);

        System.out.println();
        System.out.println("Dog: " + dog);
        System.out.println("Bird: " + bird);

        sc.close();
    }
}
