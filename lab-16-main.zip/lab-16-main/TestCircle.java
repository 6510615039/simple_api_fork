
/**
 * 
 * @author xxxxxxxxxx@cn103
 * 
 */

import java.util.Arrays;
import java.util.Random;

public class TestCircle {

    static final int MAX_OBJS = 4;

    static void println(String prefix, Circle c) {
        System.out.print(prefix);
        System.out.format(" | area: %.2f", c.getArea());
        System.out.format(" | perimeter: %.2f\n", c.getPerimeter());
    }

    public static void main(String[] args) {
        Circle[] circles = new Circle[MAX_OBJS];
        Circle c1, c2, c3, c4;
        int i;
        Random random = new Random(0);

        System.out.print("Created default circle: ");
        c1 = new Circle();
        System.out.println(c1);

        System.out.print("Create circle with 2 parameters: ");
        c2 = new Circle(4, "C2");
        System.out.println(c2);

        for (i = 0; i < MAX_OBJS; i++) {
            String name = "C" + (i + 1);
            circles[i] = new Circle(random.nextInt(50), name);
        }

        System.out.println("\nStarting objects:");
        i = 1;
        for (Circle c : circles) {
            println(i + ": " + c, c);
            i++;
        }

        Arrays.sort(circles);

        System.out.println("\nAfter sorting:");
        i = 1;
        for (Circle c : circles) {
            println(i + ": " + c, c);
            i++;
        }

        c1 = new Circle(2, "NC1");
        c2 = new Circle(2, "NC2");
        c3 = new Circle(2, "NC3");
        c4 = new Circle(2, "NC4");

        c1.set(3);
        c2.set("Circle 2");
        c3.set(4, "Circle 3");
        c4.set("Circle 4", 4);

        println("\nC1: " + c1, c1);
        println("C2: " + c2, c2);
        println("C3: " + c3, c3);
        println("C4: " + c4, c4);

        String s1 = c1.equals(c2) ? "" : "NOT ";
        String s2 = c1.equals(c3) ? "" : "NOT ";
        String s3 = c2.equals(c3) ? "" : "NOT ";
        String s4 = c3.equals(c4) ? "" : "NOT ";

        System.out.println("\nC1: " + s1 + "equal C2");
        System.out.println("C1: " + s2 + "equal C3");
        System.out.println("C2: " + s3 + "equal C3");
        System.out.println("C3: " + s4 + "equal C4");
    }
}
