
/**
 *
 * @author xxxxxxxxxx@cn103
 *
 */

public interface IpAddress {

    /**
     * Validate IP address.
     * 
     * @return true if this IP address is valid
     */
    public abstract boolean isValid();
}
