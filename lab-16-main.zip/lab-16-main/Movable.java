/**
 *
 * @author @cn103
 * 
 */

public interface Movable {

    public abstract String howToMove();

}
