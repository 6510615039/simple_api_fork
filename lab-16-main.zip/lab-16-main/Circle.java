/**
 *
 * @author @cn103
 * 
 */

public class Circle extends Shape implements Comparable<Circle> {

    public double radius;
    public String name;

    public Circle() {
        radius = 1.0;
        name = "circle";
    }

        // เพิ่มใน Circle.java
    public void set(double radius, String name) {
        this.radius = radius;
        this.name = name;
    }

    public void set(String name, double radius) {
        this.name = name;
        this.radius = radius;
    }

    public Circle(double radius, String name) {
        this.radius = radius;
        this.name = name;
    }

    public double getArea() {
        return Math.PI * radius * radius;
    }

    public double getPerimeter() {
        return 2 * Math.PI * radius;
    }

    public boolean equals(Object obj) {
        if (((Circle) obj).radius == radius && name.length() == ((Circle) obj).name.length()) {
            return true;
        } else {
            return false;
        }

    }

    public void set(double radius) {
        this.radius = radius;
    }

    public void set(String name) {
        this.name = name;
    }

    public String toString() {
        return "name = " + name + " radius = " + String.format("%.2f", radius);

    }

    public int compareTo(Circle o) {
        if (radius > o.radius) {
            return 1;
        } else if (radius < o.radius) {
            return -1;
        } else {
            if (name.length() > o.name.length()) {
                return 1;
            } else if (name.length() < o.name.length()) {
                return -1;
            } else {
                return 0;
            }
        }

    }
}
