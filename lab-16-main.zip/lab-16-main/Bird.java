/**
 *
 * @author @cn103
 * 
 */

public class Bird extends Animal implements Movable {

    protected String color;

    public Bird(int age, String color) {
        super.setAge(age);
        this.color = color;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public String eat() {
        return "bird food";
    }

    public String sound() {
        return "bird sound";
    }

    public String howToMove() {
        return "bird move";
    }

    public String toString() {
        return "age: " + age + ", color: " + color;
    }

}
