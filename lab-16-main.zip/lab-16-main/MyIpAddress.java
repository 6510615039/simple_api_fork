/**
 *
 * @author @cn103
 * 
 */
public class MyIpAddress implements IpAddress {

    private String line;

    public MyIpAddress(String line) {
        this.line = line;
    }

    public boolean countNum() {
        String[] arr = line.split("\\.");
        int count = 0;
        for (String s : arr) {
            for (int i = 0; i < s.length(); i++) {
                if (!(Character.isDigit(s.charAt(i)))) {
                    return false;
                }
            }
            count += 1;
        }
        if (count == 4) {
            return true;
        } else {
            return false;
        }
    }

    public boolean checkNum() {
        String[] arr = line.split("\\.");
        int[] numArr = new int[arr.length];
        boolean check = true;
        for (int i = 0; i < arr.length; i++) {
            numArr[i] = Integer.parseInt(arr[i]);
            if (0 <= numArr[i] && numArr[i] <= 255) {
                check = true;
            } else {
                return false;
            }
        }
        return check;
    }

    public boolean isValid() {
        if (countNum() && checkNum()) {
            return true;
        } else {
            return false;
        }
    }

    public void printWhyIsNotGood() {
        String[] parts = line.split("\\.");

        // ตรวจสอบจำนวนส่วน
        if (parts.length != 4) {
            System.out.println("Invalid: IP address must contain exactly 4 parts separated by dots.");
            return;
        }

        for (String part : parts) {
            // ตรวจสอบว่าเป็นตัวเลขหรือไม่
            if (!part.matches("\\d+")) {
                System.out.println("Invalid: Each part must contain only digits.");
                return;
            }

            // ตรวจสอบว่าตัวเลขอยู่ในช่วง 0 - 255 หรือไม่
            int value = Integer.parseInt(part);
            if (value < 0 || value > 255) {
                System.out.println("Invalid: Each number must be between 0 and 255.");
                return;
            }
        }
    }
}
