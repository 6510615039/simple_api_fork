/**
 *
 * @author @cn103
 * 
 */

public class Dog extends Animal implements Movable {

    protected String color;

    public Dog(int age, String color) {
        super.setAge(age);
        this.color = color;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public String eat() {
        return "dog food";
    }

    public String sound() {
        return "dog sound";
    }

    public String howToMove() {
        return "dog move";
    }

    public String toString() {
        return "age: " + age + ", color: " + color;
    }

}
